package com.question.controller;


import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.question.bean.AnswerDetails;
import com.question.bean.AnswerDetailsList;
import com.question.bean.Answers;
import com.question.bean.Message;
import com.question.bean.PagingDetails;
import com.question.bean.PagingList;
import com.question.bean.QuestionContract;
import com.question.bean.QuestionDetails;
import com.question.bean.QuestionResponse;
import com.question.bean.Questions;
import com.question.bean.QuestionsList;
import com.question.bean.QuestionsResponse;
import com.question.bean.Response;
import com.question.bean.ServiceContract;
import com.question.service.QuestionService;



@RequestMapping("/api")
@RestController
public class QuestionController {
	@Autowired
    private QuestionService questionservice;
	
	@GetMapping("/getAllQuestions")
	public ResponseEntity<Object> getAllQuestions(
			@RequestParam(value = "pageNumber" , defaultValue = "1", required = false) int pageNumber,
            @RequestParam(value = "pageSize" , defaultValue = "2", required = false) int pageSize){
		QuestionContract questionContract=new QuestionContract();
		Questions questions=new Questions();
		QuestionsResponse questionsResponse=new QuestionsResponse();
		PagingDetails pagingdetails=new PagingDetails();
		List<QuestionsList> questionsList=questionservice.getAllQuestions(pageNumber,pageSize);
		int numberOfQuestions=questionservice.count();
		List<PagingList> paginglist=questionservice.pagination(pageNumber);
		pagingdetails.setLimits(pageSize);
		pagingdetails.setTotalnumberofpages(numberOfQuestions,pageSize);
		pagingdetails.setPagingList(paginglist);
		questionsResponse.setQuestions(questions);
		questionsResponse.setPagingDetails(pagingdetails);
		questions.setNumberOfQuestions(numberOfQuestions);
		questions.setQuestionsList(questionsList);
		questionContract.setQuestionsResponse(questionsResponse);
		return new ResponseEntity<>(questionContract,HttpStatus.OK);
	}
	
	@GetMapping("/{questionid}")
    public ResponseEntity<Object> getQuestionsById(@PathVariable int questionid ){
		 
		 try {
	            QuestionDetails questiondetails=new QuestionDetails();
	            QuestionResponse questionresponse=new QuestionResponse();
	            ServiceContract servicecontract=new ServiceContract();
	            Answers answers=new Answers();
	            AnswerDetails answerdetails=new AnswerDetails();
	            QuestionsList getQuestionsById  = questionservice.getQuestionsById(questionid);
	            int numberofanswers=questionservice.countanswers();
	            List<AnswerDetailsList> answerdetailslist=questionservice.getAnswers(questionid);
	            questiondetails.setQuestionsList(getQuestionsById);
	            questionresponse.setQuestionDetails(questiondetails);
	            answers.setNumberOfAnswers(numberofanswers);
	            answers.setAnswerDetailsList(answerdetailslist);
	            answerdetails.setAnswers(answers);
	            questionresponse.setAnswerDetails(answerdetails);
	            servicecontract.setQuestionResponse(questionresponse);
	         return new ResponseEntity<>(servicecontract, HttpStatus.OK);
	        
        }
        catch(Exception e) {
            Response response = new Response();
            Message message = new Message();
            message.setCode(404);
            message.setType("Not Found");
            message.setDescription("ID Not Found");
            response.setMessage(message);
            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        }
    }
	@PostMapping("/addquestions")
	public ResponseEntity<Response> addQuestion(@RequestBody QuestionsList questionname){
		
		if(questionname.getQuestionname()==null||questionname.getQuestionid()==0||questionname.getUsersDetails().getUsername()==null){
			Response response=new Response();
			Message message=new Message();
			message.setCode(400);
			message.setType("Bad Request");
			message.setDescription("Invalid Request");
			response.setMessage(message);
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		}
		try {
	        Response response = new Response(); 
	        Message message = new Message();	   

	         Date date=new Date();
	        SimpleDateFormat dateForm=new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	        questionname.setCreatedon(dateForm.format(date));
	        questionname.setModifiedon(dateForm.format(date));
	        QuestionsList addQuestion=questionservice.addQuestion(questionname);
	        message.setCode(200);
			message.setType("Success");
			message.setDescription("Question has been Updated Successfully");
			response.setMessage(message);
	        response.setQuestionsList(addQuestion);
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (Exception e) {
        	 Response response = new Response();
        	 Message message=new Message();
        	 message.setCode(409);
        	 message.setType("Conflict");
        	 message.setDescription("Id Already Exists !!");
        	 response.setMessage(message);
             return new ResponseEntity<>(response, HttpStatus.CONFLICT);
        }

    }
	@PutMapping("/{id}")
	public ResponseEntity<Response> updateQuestion(@RequestBody QuestionsList questionname){
		QuestionsList getQuestionsById=questionservice.updateQuestion(questionname);
		if(getQuestionsById==null) {
			Message message = new Message();
            Response response = new Response();
            message.setCode(400);
            message.setType("NOT FOUND");
            message.setDescription("Invalid Request");
            response.setMessage(message);
            return new ResponseEntity<>(response,HttpStatus.BAD_REQUEST);
		}
		else {
			Message message=new Message();
			Response response = new Response();
			Date date=new Date();
	        SimpleDateFormat dateForm=new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	        questionname.setModifiedon(dateForm.format(date));
			QuestionsList updateQuestions=questionservice.updateQuestion(questionname);
			message.setCode(200);
			message.setType("Success");
			message.setDescription("Question has been Updated Successfully");
			response.setMessage(message);
			response.setQuestionsList(updateQuestions);
			return new ResponseEntity<>(response,HttpStatus.OK);
		}
	}
	@DeleteMapping("/{questionid}")
    public ResponseEntity<Response> deleteQuestion(@PathVariable int questionid)
    {
        try {
            Response response=new Response();
            Message message=new Message();
            questionservice.deleteQuestion(questionid);
           message.setCode(200);
            message.setType("200 OK");
            message.setDescription("Deleted Successfully");
            response.setMessage(message);
            
        return new ResponseEntity<>(response,HttpStatus.OK);
        }
        catch(Exception e)
        
        {
            Response response=new Response();
            Message message= new Message();
            message.setCode(200);
            message.setType("Deleting");
            message.setDescription(" this question is already deleted");
            response.setMessage(message);
            return new ResponseEntity<>(response,HttpStatus.OK);
        }
        }
}
