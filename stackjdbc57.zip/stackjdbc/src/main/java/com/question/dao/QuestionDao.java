package com.question.dao;


import java.sql.Types;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.question.bean.AnswerDetailsList;
import com.question.bean.PagingList;
import com.question.bean.QuestionsList;
import com.question.mapper.QuestionsMapper;



@Repository
public class QuestionDao {
	@Autowired
    JdbcTemplate jdbcTemplate;


	public List<QuestionsList> getAllQuestions() {
        return jdbcTemplate.query("select * from questioncontract", new QuestionsMapper());
   }
   public QuestionsList getQuestionsById(int questionid) {
     return  jdbcTemplate.queryForObject("SELECT * FROM questioncontract WHERE questionid=?",new QuestionsMapper(),questionid);
       
      
   }
	
	 public QuestionsList addQuestion(QuestionsList questionname) {
	   jdbcTemplate.update("INSERT INTO questioncontract (questionid, questionname, description, numberofvotes, numberofviews,"
	   		+ "numberofanswers, createdon,  field1,field2, username, reputationscore, numberofgoldbadges, "
	   		+ "numberofbronzebadges, numberofsilverbadges) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
			   questionname.getQuestionid(),questionname.getQuestionname(),questionname.getDescription(),questionname.getNumberofvotes(),
			   questionname.getNumberofviews(),questionname.getNumberofanswers(),questionname.getCreatedon(),
			   questionname.getTagsList().getField1(),questionname.getTagsList().getField2(),questionname.getUsersDetails().getUsername(),
			   questionname.getUsersDetails().getReputationscore(),questionname.getUsersDetails().getNumberofgoldbadges(),
			   questionname.getUsersDetails().getNumberofbronzebadges(),questionname.getUsersDetails().getNumberofsilverbadges());
	   return getQuestionsById(questionname.getQuestionid());
   }
   public QuestionsList updateQuestion(QuestionsList questionname) {
	   jdbcTemplate.update("UPDATE questioncontract SET questionname=?,username=?,modifiedon=? WHERE questionid = ?",
	   		questionname.getQuestionname(),questionname.getUsersDetails().getUsername(),questionname.getModifiedon(),
	   		questionname.getQuestionid());
	   return questionname;
 }
   
  
   public QuestionsList deleteQuestion(int questionid) {
	   jdbcTemplate.update("delete from questioncontract where questionid=?",questionid);
	   return null;
   }
   public int count() {
	   return jdbcTemplate.queryForObject(
			   "SELECT COUNT(*) FROM questioncontract", Integer.class);
}
   public List<PagingList> getAll() {
	   return jdbcTemplate.query("select * from pagingList", BeanPropertyRowMapper.newInstance(PagingList.class));
   }
   public int countanswers() {
       return jdbcTemplate.queryForObject("select count(*) from answerdetails", Integer.class);
   }
   public List<AnswerDetailsList> getAnswers(int questionid) {
	     return jdbcTemplate.query("SELECT answerid,answerbody,numberofvotes,comments FROM  answerdetaills f   WHERE f.questionId = ?",
	                     new Object[] { questionid },new int[] { Types.VARCHAR },new BeanPropertyRowMapper(AnswerDetailsList.class));   
	}

   
}
