package com.question.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.RowMapper;

import com.question.bean.QuestionContract;
import com.question.bean.Questions;
import com.question.bean.QuestionsList;
import com.question.bean.QuestionsResponse;
import com.question.bean.TagsList;
import com.question.bean.UserDetails;


public class QuestionsMapper implements RowMapper<QuestionsList>{
	public QuestionsList mapRow(ResultSet rs,int i)throws SQLException{
		QuestionContract questionContract=new QuestionContract();
		QuestionsResponse questionsResponse=new QuestionsResponse();
		Questions questions=new Questions();
		List<QuestionsList> questionsList=new ArrayList<>();
		TagsList tagsList=new TagsList();
		UserDetails userDetails=new UserDetails();
		QuestionsList question= new QuestionsList();

		question.setQuestionid(rs.getInt("questionid"));
		question.setQuestionname(rs.getString("questionname"));
		question.setDescription(rs.getString("description"));
		question.setNumberofvotes(rs.getInt("numberofvotes"));
		question.setNumberofviews(rs.getInt("numberofviews"));
		question.setNumberofanswers(rs.getInt("numberofanswers"));
		question.setCreatedon(rs.getString("createdon"));
		question.setModifiedon(rs.getString("modifiedon"));
		tagsList.setField1(rs.getString("field1"));
		tagsList.setField2(rs.getString("field2"));
		
		userDetails.setUsername(rs.getString("username"));
		userDetails.setReputationscore(rs.getInt("reputationscore"));
		userDetails.setNumberofgoldbadges(rs.getInt("numberofgoldbadges"));
		userDetails.setNumberofbronzebadges(rs.getInt("numberofbronzebadges"));
		userDetails.setNumberofsilverbadges(rs.getInt("numberofsilverbadges"));
		
		question.setTagsList(tagsList);
		question.setUsersDetails(userDetails);
		questionsList.add(question);
		questions.setQuestionsList(questionsList);
		questionsResponse.setQuestions(questions);
		questionContract.setQuestionsResponse(questionsResponse);
		return question;
		
	
	}

}
