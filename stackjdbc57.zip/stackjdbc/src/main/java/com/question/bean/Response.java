package com.question.bean;

public class Response {
	private QuestionsList questionsList;
	private Message message;
	
	public Response() {
		super();
	}
	public Response(QuestionsList questionsList, Message message) {
		super();
		this.questionsList = questionsList;
		this.message = message;
	}


	public QuestionsList getQuestionsList() {
		return questionsList;
	}

	public void setQuestionsList(QuestionsList questionsList) {
		this.questionsList = questionsList;
	}

	public Message getMessage() {
		return message;
	}

	public void setMessage(Message message) {
		this.message = message;
	}

}
