package com.question.bean;



import java.util.List;



public class Answers {
    private int numberOfAnswers;
    private List<AnswerDetailsList> answerDetailsList;
    public Answers() {
        super();
    }
    public Answers(int numberOfAnswers, List<AnswerDetailsList> answerDetailsList) {
        super();
        this.numberOfAnswers = numberOfAnswers;
        this.answerDetailsList = answerDetailsList;
    }
    public int getNumberOfAnswers() {
        return numberOfAnswers;
    }
    public void setNumberOfAnswers(int numberOfAnswers) {
        this.numberOfAnswers = numberOfAnswers;
    }
    public List<AnswerDetailsList> getAnswerDetailsList() {
        return answerDetailsList;
    }
    public void setAnswerDetailsList(List<AnswerDetailsList> answerDetailsList) {
        this.answerDetailsList = answerDetailsList;
    }



   
}