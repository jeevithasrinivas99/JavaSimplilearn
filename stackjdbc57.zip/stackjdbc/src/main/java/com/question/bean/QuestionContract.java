package com.question.bean;

public class QuestionContract {
	private QuestionsResponse questionsResponse;

	public QuestionContract() {
		super();
	}

	public QuestionContract(QuestionsResponse questionsResponse) {
		super();
		this.questionsResponse = questionsResponse;
	}

	public QuestionsResponse getQuestionsResponse() {
		return questionsResponse;
	}

	public void setQuestionsResponse(QuestionsResponse questionsResponse) {
		this.questionsResponse = questionsResponse;
	}
	

}
