package com.question.bean;



public class QuestionDetails {
    private QuestionsList questionsList;
    
    public QuestionDetails() {
        super();
    }
    public QuestionDetails(QuestionsList questionsList) {
        super();
        this.questionsList = questionsList;
    }
    public QuestionsList getQuestionsList() {
        return questionsList;
    }
    public void setQuestionsList(QuestionsList questionsList) {
        this.questionsList = questionsList;
    }
    
}