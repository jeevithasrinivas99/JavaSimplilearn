package com.question.bean;



public class ServiceContract {
    private QuestionResponse questionResponse;



   public ServiceContract() {
        super();
    }



   public ServiceContract(QuestionResponse questionResponse) {
        super();
        this.questionResponse = questionResponse;
    }



   public QuestionResponse getQuestionResponse() {
        return questionResponse;
    }



   public void setQuestionResponse(QuestionResponse questionResponse) {
        this.questionResponse = questionResponse;
    }
    
}