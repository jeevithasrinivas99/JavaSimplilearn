package com.question.bean;

import java.util.List;

public class Questions {
	private int numberOfQuestions;
	private List<QuestionsList> questionsList;

	public Questions() {
		super();
	}

	public Questions(int numberOfQuestions, List<QuestionsList> questionsList) {
		super();
		this.numberOfQuestions = numberOfQuestions;
		this.questionsList = questionsList;
	}

	public int getNumberOfQuestions() {
		return numberOfQuestions;
	}

	public void setNumberOfQuestions(int numberOfQuestions) {
		this.numberOfQuestions = numberOfQuestions;
	}

	public List<QuestionsList> getQuestionsList() {
		return questionsList;
	}

	public void setQuestionsList(List<QuestionsList> questionsList) {
		this.questionsList = questionsList;
	}
}