package com.question.bean;



public class AnswerDetails {
    private Answers answers;



   public AnswerDetails() {
        super();
    }



   public AnswerDetails(Answers answers) {
        super();
        this.answers = answers;
    }



   public Answers getAnswers() {
        return answers;
    }



   public void setAnswers(Answers answers) {
        this.answers = answers;
    }
    



}