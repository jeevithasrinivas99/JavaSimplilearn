package com.question.bean;

public class PagingList {
	String id;
	int pagenumber;
	public PagingList() {
		super();
	}
	public PagingList(String id, int pageNumber) {
		super();
		this.id = id;
		pagenumber = pageNumber;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getPageNumber() {
		return pagenumber;
	}
	public void setPageNumber(int pageNumber) {
		pagenumber = pageNumber;
	}

	
}
