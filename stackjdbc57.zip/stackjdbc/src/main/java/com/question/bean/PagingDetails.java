package com.question.bean;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
public class PagingDetails {
    
    
    private int limits;
    private int totalnumberofpages;
    private List<PagingList> pagingList;
    
    public int getLimits() {
        return limits;
    }
    public void setLimits(int limits) {
        this.limits = limits;
    }
    public int getTotalnumberofpages() {
        return totalnumberofpages;
    }
public void setTotalnumberofpages(int numberOfQuestions, int pageSize) {
        
        int rem = numberOfQuestions%pageSize;
        int pages = numberOfQuestions/pageSize;
        
        if(rem==0) {
        this.totalnumberofpages = pages;
        }
        else {
            this.totalnumberofpages = pages+1;
        }
            
    }
    
    public List<PagingList> getPagingList() {
        return pagingList;
    }
    public void setPagingList(List<PagingList> pagingList) {
        this.pagingList = pagingList;
    }
    
   



}