package com.question.bean;



public class QuestionResponse {
    private QuestionDetails questionDetails;
    private AnswerDetails answerDetails;
    public QuestionResponse() {
        super();
    }
    public QuestionResponse(QuestionDetails questionDetails, AnswerDetails answerDetails) {
        super();
        this.questionDetails = questionDetails;
        this.answerDetails = answerDetails;
    }
    public QuestionDetails getQuestionDetails() {
        return questionDetails;
    }
    public void setQuestionDetails(QuestionDetails questionDetails) {
        this.questionDetails = questionDetails;
    }
    public AnswerDetails getAnswerDetails() {
        return answerDetails;
    }
    public void setAnswerDetails(AnswerDetails answerDetails) {
        this.answerDetails = answerDetails;
    }



}