package com.question.bean;



public class AnswerDetailsList {
    private int answerid;
    private String answerbody;
    private String comments;
    public AnswerDetailsList() {
        super();
    }
    public AnswerDetailsList(int answerid, String answerbody, String comments) {
        super();
        this.answerid = answerid;
        this.answerbody = answerbody;
        this.comments = comments;
    }
    public int getAnswerid() {
        return answerid;
    }
    public void setAnswerid(int answerid) {
        this.answerid = answerid;
    }
    public String getAnswerbody() {
        return answerbody;
    }
    public void setAnswerbody(String answerbody) {
        this.answerbody = answerbody;
    }
    public String getComments() {
        return comments;
    }
    public void setComments(String comments) {
        this.comments = comments;
    }
    



}