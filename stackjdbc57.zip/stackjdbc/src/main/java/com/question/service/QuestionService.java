package com.question.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.question.bean.AnswerDetailsList;
import com.question.bean.PagingList;
import com.question.bean.QuestionsList;
import com.question.dao.QuestionDao;


@Service
public class QuestionService {
	@Autowired
	private QuestionDao questiondao;
	
	public List<QuestionsList> getAllQuestions( int pageNumber,  int pageSize){
        Pageable paging = PageRequest.of(pageNumber, pageSize);
                
                List<QuestionsList> getallPage = questiondao.getAllQuestions();
                
                int start = Math.min((int)paging.getOffset(), getallPage.size());
                int end = Math.min((start + paging.getPageSize()), getallPage.size());
                
                Page<QuestionsList> page = new PageImpl<>(getallPage.subList(start, end), paging, getallPage.size());
                        return page.getContent();
                        
                 }
	
	public List<PagingList> pagination(int pageNumber){
        List<PagingList> pagelist = new ArrayList<>();
        if(pageNumber==0) {
            PagingList page = new PagingList();
            page.setId("current");
            page.setPageNumber(pageNumber);
            
            PagingList page1 = new PagingList();
            page1.setId("next");
            page1.setPageNumber((pageNumber+1));
            
            pagelist.add(page);
            pagelist.add(page1);
   }
        else if(pageNumber==1) {
            PagingList page = new PagingList();
            page.setId("current");
            page.setPageNumber(pageNumber);
            
            PagingList page1 = new PagingList();
            page1.setId("next");
            page1.setPageNumber((pageNumber+1));
            
            pagelist.add(page);
            pagelist.add(page1);
    }
        
        else {
            PagingList page = new PagingList();
            page.setId("current");
            page.setPageNumber(pageNumber);
            
            PagingList page1 = new PagingList();
            page1.setId("next");
            page1.setPageNumber((pageNumber+1));
            
            PagingList page2 = new PagingList();
            page2.setId("previous");
            page2.setPageNumber((pageNumber-1));

             pagelist.add(page2);
            pagelist.add(page);
            pagelist.add(page1);
    }
        
        
        return pagelist;
    }
	public QuestionsList getQuestionsById(int questionid) {
		return questiondao.getQuestionsById(questionid);
	}
	public QuestionsList addQuestion(QuestionsList questionname) {
		return questiondao.addQuestion(questionname);
	}
	public QuestionsList updateQuestion(QuestionsList questionname) {
		return questiondao.updateQuestion(questionname);
	}
	public QuestionsList deleteQuestion(int questionid) {
		return questiondao.deleteQuestion(questionid);
	}
	public int count(){
		return questiondao.count();
	}
	public List<PagingList> getAll(){
		return questiondao.getAll();
	}
	public int countanswers() {
        return questiondao.countanswers();
    }
	 public List<AnswerDetailsList> getAnswers(int questionid)  {
	        return questiondao.getAnswers(questionid);
	    }
	
}
